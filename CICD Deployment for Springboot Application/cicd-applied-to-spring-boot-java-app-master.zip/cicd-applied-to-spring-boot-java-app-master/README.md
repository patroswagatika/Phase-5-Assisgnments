# cicd-applied-to-spring-boot-java-app
Implementing Continuous Integration/Continuous Delivery on Spring Boot Java App 

[![Build Status](https://travis-ci.com/FanJups/cicd-applied-to-spring-boot-java-app.svg)](https://travis-ci.com/FanJups/cicd-applied-to-spring-boot-java-app)
[![docker build](https://img.shields.io/docker/cloud/build/fanjups/cicd-applied-to-spring-boot-java-app)](https://cloud.docker.com/u/fanjups/repository/docker/fanjups/cicd-applied-to-spring-boot-java-app)
[![codecov](https://codecov.io/gh/FanJups/cicd-applied-to-spring-boot-java-app/branch/master/graph/badge.svg)](https://codecov.io/gh/FanJups/cicd-applied-to-spring-boot-java-app)
[![Quality Gate](https://sonarcloud.io/api/project_badges/measure?project=com.cicd:cicd-applied-to-spring-boot-java-app&metric=alert_status)](https://sonarcloud.io/dashboard/index/com.cicd:cicd-applied-to-spring-boot-java-app)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)


Please read this first : https://github.com/FanJups/cicd-applied-to-spring-boot-java-app/issues/1

I'm so sorry to not apply the changes right now because I'm seeking job.

Read the article and this issue.

I'll come back soon.

## I've added Javadoc plugin in pom.xml

https://fanjups.github.io/cicd-applied-to-spring-boot-java-app/project-reports.html

## I've added packaging jar 

```
<packaging> jar </packaging>
```

## I've added mvn clean in .travis.yml

## I've created .dockerignore
